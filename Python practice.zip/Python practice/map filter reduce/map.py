n=input().split()
mapping=map(int,n)
convert_to_list=list(mapping)
print(convert_to_list)


# converting given sequence to integer
conv_to_int=list(map(int,input().split()))
print(conv_to_int)

# 

convert_to_list2=print(list(map(int,input().split())))

