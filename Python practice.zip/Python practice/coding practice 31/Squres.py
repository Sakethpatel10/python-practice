n=int(input())
dict_a={}
for i in range(1,n+1):
    dict_a[i]=i**2
print(dict_a)
