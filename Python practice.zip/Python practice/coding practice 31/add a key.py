students_dict={"ram":"cricket","naresh":"football","vani":"Tennis","Rahim":"cricket"}
# ADDING A KEY
students_dict["Ramesh"]="Cricket"
# UPDATING A KEY

students_dict["Rahim"]="Hockey"
students_dict["vani"]="Badminton"

# DELETING A KEY
del students_dict["vani"]
print(students_dict)