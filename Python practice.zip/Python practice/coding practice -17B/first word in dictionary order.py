word=input()
split=word.lower().split()
split.sort()
print(split[0])