n=[[1,1,1],[1,0,1],[1,1,1]]
# length=len(n[1])
# for k in range(length):
#     n[1][k]=0
# print(n[1])

for i in n:
    length_of_row=len(i)

    for m in range(length_of_row):
        column=0
        if i[m]==0:
            row=n.index(i)
            column=i.index(i[m])
        print(n[m][column])

            


   
    
#     for j in i:
#         row=0
#         column=0
       
#         if j==0:
#             row=n.index(i)
#             column=i.index(j)
#             length=len(n[row])
#             for num in range(length):
#                 n[row][num]=0
#     print(i)
    
            

# print(n)
