import datetime
date_and_time=datetime.date(2022,1,2)
print(date_and_time)

today_date=datetime.date.today()
print(today_date.day)
