from datetime import datetime,timedelta
dt1=datetime.now()
dt2=datetime(2018,5,2)
duration=dt1-dt2
print(duration)