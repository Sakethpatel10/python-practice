a=()
b=(1)
c=(1,)
d=(1,3)
print(type(a))
print(type(b))
print(type(c))
print(type(d))

a=[1,2,3,4,5,7,5,5]
conv=set(a)
print(conv)
b=(1,23,4,5)
c=5
b=b+c
print(b)