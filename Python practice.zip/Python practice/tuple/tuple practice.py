a=(1,2,3,4,4,5)
length=len(a)
print(length)
print(a[0:5:1])
# Hydrating over a loop
for i in a:   
    print(i)



