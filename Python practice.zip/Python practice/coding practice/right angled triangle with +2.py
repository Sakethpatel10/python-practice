n=int(input())
for i in range(1,n+1):
    if i==1:
        print(i*"* ")
    else:
        print((i*2-1)*"* ")
        