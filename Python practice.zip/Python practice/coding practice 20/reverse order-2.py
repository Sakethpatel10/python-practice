n=int(input())
list=[]
for i in range(n):
    inputs=input()
    list=list+[inputs]
print(list[::-1])

