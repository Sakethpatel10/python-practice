list=[1,"yellow",3,"green"]
print(list[3])
print(list[1])