list=['rose',183,148,123.64,False]
print(list)