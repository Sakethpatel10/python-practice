# a=input()
# b=list(a)
# print(b)

word=input()
print(list(word))

