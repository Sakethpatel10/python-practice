list=[10,20,40,100]
n=int(input())
first_num=[n]+list #to add number in starting
last_num=list+[n]  #to add the number in last
print(first_num)
print(last_num)