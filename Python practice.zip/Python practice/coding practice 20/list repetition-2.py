n=int(input())
times=int(input())
lists=[n]
nums=lists*times
print(nums)

