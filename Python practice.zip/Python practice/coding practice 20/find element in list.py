list=["5","eat","9.80","water","python","-678","7685.26","-2.5","sing"]
word=input()
if word in list:
    print(True)
else:
    print(False)