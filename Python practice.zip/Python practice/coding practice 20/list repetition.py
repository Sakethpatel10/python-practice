list=[1,"two","3","4.0"]
output=list*2
print(output)