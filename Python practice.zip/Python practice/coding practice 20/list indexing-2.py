programmin_languages_list=["c","java","python","ruby","c++","javascript","php","kotlin"]
a=int(input())
for i in range(a):
    inputs=int(input())
    print(programmin_languages_list[inputs])