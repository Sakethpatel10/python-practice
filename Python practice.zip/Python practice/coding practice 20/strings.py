# string="program"
# print(string[::-1])



# # ARRANGING ITEMS IN ORDER SPLIITING AND SORTING

# lists="saketh patel is the next ceo of the google"
# splitting=lists.split()
# splitting.sort()
# print(splitting)

lists="saketh patel is the next ceo"
splitting=lists.split("next")
joining="future".join(splitting)
print(splitting)
print(joining)