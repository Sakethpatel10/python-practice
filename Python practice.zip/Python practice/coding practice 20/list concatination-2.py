list=["apple","78","970.3"]
n=int(input())
for i in range(n):
    inputs=input()
    list=list+[inputs]
print(list)