# word=input()
# splitting=word.split()
# length=len(splitting)
# print(length)
# list=[]
# for i in range(length):
#     j=length-i
#     list=list+[splitting[j]]
# print(list)

# word=input()
# splitting =word.split()
# print(splitting)
# length=len(splitting)
# list=[]
# print(splitting[::-1])

word=input()
length=len(word)
print(word[::-1])


