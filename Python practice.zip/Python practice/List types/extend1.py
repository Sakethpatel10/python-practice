list_a=[5,7,'Rohith',"virat","Dhoni"]
n=input().split()
list_a.extend(n)
print(list_a)