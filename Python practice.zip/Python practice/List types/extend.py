list_a=[1,2,3,0]
# list_b=[4,5,6,7]
# list_a.extend(list_b)
# print(list_a)
# print(list_a.pop(2))
list_a.remove(2)
print(list_a)