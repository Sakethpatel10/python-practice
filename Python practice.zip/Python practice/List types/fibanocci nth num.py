# def fibonacci_series(n):
#     if n<=1:
#         return n 
#     else:
#         return fibonacci_series(n-1)+fibonacci_series(n-2)
# n=int(input())
# result=fibonacci_series(n)
# print(result)

n=int(input())
fib_ser=[0,1]
for i in range(2,n+1):
    fib_ser.append(fib_ser[i-1]+fib_ser[i-2])
    print(fib_ser)
