list_a=[10,30,50,60,80,90]
value=int(input())
n=int(input())
list_a.insert(2,100)
print(list_a)


