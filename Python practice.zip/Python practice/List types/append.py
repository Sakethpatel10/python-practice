list_a=[]
for x in range(1,4):
    list_a.append(x)
    print(list_a)