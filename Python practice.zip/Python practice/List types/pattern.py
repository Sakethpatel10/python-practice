n=int(input())
for i in range(1,n+1):
    sum=''
    next=''
    spacing=n*2-i*2
    for j in range(1,i+1):
        sum+=str(j)
    for k in range(1,i+1):
        k=i+1-k
        next+=(str(k))
    print(sum+spacing*" "+next)



# input=any number like 3 

