list_a=["cricket","hockey","football","badminton"]
list_a.append(input())
print(list_a)
