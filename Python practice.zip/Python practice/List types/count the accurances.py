list_a=[1,2,3,4,4,6,7,4,9,4]
counts=list_a.count(9)
print(counts)
indexs=list_a.index(3)
print(indexs)
# removing=list_a.remove(4)
print(list_a.clear())