set_a={1,3,4,5,6,7}
set_b={1,2,9,7}
difference=set_a-set_b
print(difference)

#it will print only set_a values 
# it doesnt print same values in set_A and set_b
# it doesnt print set_b values when we use set_a-set_b
