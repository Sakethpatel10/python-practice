set_a={1,3,5,6,7}
set_b={1,2,4,5,8}
symmetric_difference=set_a ^ set_b
symmetric_differences=set_a.symmetric_difference(set_b)
print(symmetric_difference)
print(symmetric_differences)

# symmetric difference means it doesnt print similar values in set_A and set_b
# it prints set_a and set_b values not same values 