set_a={1,3,4,5,6,7}
set_b={1,2,8,9,5}
intersection=set_a & set_b
intersection_1=set_a.intersection(set_b)
print(intersection)
print(intersection_1)