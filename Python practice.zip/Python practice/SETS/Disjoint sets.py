set_a={1,2,3,4,5}
set_b={7,8,9,10,11}
disjoint_set=set_a.isdisjoint(set_b)
print(disjoint_set)

# disjoint means the set_a and set_b are not same then it prints true

set_1={1,2,3,4,5}
set_2={5,6,7,8,9}
disjoint_set_1=set_1.isdisjoint(set_2)
print(disjoint_set_1)