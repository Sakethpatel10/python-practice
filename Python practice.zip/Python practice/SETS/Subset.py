set_a={1,2,3,4,5,67}
set_b={1,2,3,4}
subset=set_b.issubset(set_a)
print(subset)

# all the values in the set_b are present in the set_a so the set_b is the subset of the set_a

set_1={1,2,3,4,5,6}
set_2={1,2,3,100}
subset_2=set_2.issubset(set_1)
print(subset_2)
