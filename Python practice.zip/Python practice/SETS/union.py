set_a={1,3,4,5,7,8}
set_b={1,2,6,7,9}
union=set_a|set_b
union_1=set_a.union(set_b)
print(union)
print(union_1)