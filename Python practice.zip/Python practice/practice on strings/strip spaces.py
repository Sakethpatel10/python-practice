word=input()
stripping=word.strip()
print(stripping)