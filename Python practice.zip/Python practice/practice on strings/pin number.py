pin=input()
is_digit=pin.isdigit()
print(is_digit)