word=input()
print(word.lower())