word=input()
upperCase=word.upper()
print(upperCase)
reverse=upperCase[::-1]
is_palindrome=upperCase==reverse
print(is_palindrome)

