word=input()
len_of_word=len(word)
slicing=word[2:len_of_word:3]
print(slicing)
