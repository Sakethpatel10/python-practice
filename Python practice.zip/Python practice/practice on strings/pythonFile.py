word=input()
is_pythonFile=word.endswith(".py")
print(is_pythonFile)