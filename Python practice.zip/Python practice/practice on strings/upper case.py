word=input()
print(word.upper())

