date=input()
changeFormat=date.replace("-","/")
print(changeFormat)