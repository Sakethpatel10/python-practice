n=input()
print("first program")
