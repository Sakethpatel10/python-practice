word=input()
sum=""
for i in word:
    if i==" ":                                                                  
        break
    else:
        sum=sum+i
print(sum)