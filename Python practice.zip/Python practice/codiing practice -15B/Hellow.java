public class Hellow{
    public static void main(String[] Args){
        System.out.print("hellow world");
        
    }
}