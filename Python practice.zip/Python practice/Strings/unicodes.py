for i in range(2309,2322):
    print(chr(i))