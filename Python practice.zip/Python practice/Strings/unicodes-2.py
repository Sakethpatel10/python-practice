print("a"<"A")
print("BAD"<="BAT")
print("98"<="123")
help("keywords")

