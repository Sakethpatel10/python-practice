name=int(input())
count=0
def printing(name):
    
    if name==1:
        return name
    else:
        return name*printing(name-1)
print(printing(name))
