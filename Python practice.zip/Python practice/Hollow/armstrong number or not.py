n=input()
sum=0
for  i in n:
    sum+=int(i)**3
print(sum)
if sum==int(n):
    print("armstrong")
else:
    print("not a armstrong number")







# n=153
# print("armstrong number")