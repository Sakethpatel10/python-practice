num1=int(input())
num2=int(input())
max_num=max(num1,num2)
gcd=0
for i in range(1,num2+1):
    if num1%i==0 and num2%i==0:
        gcd=i
print(gcd)
