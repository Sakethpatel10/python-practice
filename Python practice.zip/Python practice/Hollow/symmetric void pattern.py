n=int(input())

    
for k in range(0,(n*2)):
    
    sum=''
    if k==0 or k==(n*2)-1:
        sum+=(2*n)*"* "
   
    if k<n and k>0  :
        spaces=2*k
        k=n-k

        sum+=str(k*"* ")+spaces*"  "+str(k*"* ")
    if k>=n  and k<(n*2)-1:
        k=k-(n-1)
        spaces=2*n-k*2
        sum+=str(k*"* ")+spaces*"  "+str(k*"* ")
    # if k==n:
    #     sum+="* "+(2*n-2)*"  "+"* "
    print(sum)