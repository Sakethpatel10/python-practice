# str_1=input().split(",")
# tuple_a=()
# # print(str_1)
# list=[]
# for i in str_1:
#     list=list+[i]
# tuple_a=tuple(list)
# print(tuple_a)

str_a="saketh".split()
str_a[0]="p"
print(str_a)
