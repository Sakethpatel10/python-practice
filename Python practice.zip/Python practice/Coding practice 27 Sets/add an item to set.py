set_a={"pencil"}
word=input()
list=[word]
for i in set_a:
    list=list+[i]
tuple_a=tuple(list)
print(tuple_a)