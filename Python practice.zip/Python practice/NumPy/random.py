import numpy as np
from numpy import random

x=random.randint(100)
print(x)