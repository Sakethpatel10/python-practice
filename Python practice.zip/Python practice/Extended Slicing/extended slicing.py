word="-R-A-V-I-"
slicing=word[1:8:2]
print(slicing)

x="waterfall"
part=x[1:8:3]
print(part)