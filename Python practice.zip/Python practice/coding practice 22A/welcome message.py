def say_wishes(string):
    print("hellow "+string)
string=input()
say_wishes(string)
