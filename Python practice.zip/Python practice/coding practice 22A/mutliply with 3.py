def multiply(num):
    print(3*int(num))
num=input()
multiply(num)