def print_arg(string):
    print(string)
name=input()
print_arg(name)
