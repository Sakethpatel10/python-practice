a="saketh"
def adding(a,b):
    c=5 
    print(c)
    return a+b+c
