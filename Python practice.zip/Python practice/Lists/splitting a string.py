nums="1, 2 ,3  ,       4"
num_list=nums.split(",")
print(num_list)

string_a="python is a programming language"
list_a=string_a.split("a")
joining="good".join(list_a)
print(joining)