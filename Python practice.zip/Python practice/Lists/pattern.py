# n=int(input())
# for i in range(1,n+1):
#     print(i*"* ")

# list_1 =[12,13,15]
# listing=[]
# for i in list_1:
#     listing+=[sum(int(num) for num in str(i))]
# print(listing)
# print(max(list_1))

# lists=[22,33,44,21,77]
# maximum=0
# for i in lists:
#     summing=0
#     for num in str(i):
#         int_value=int(num)
#         summing+=int_value
#     if summing==4:
#         print(i)
                
# lists=[22,33,44,55,664,4]
# def finding(arr):
#     length=len(lists)
#     for i in range(length):

#         for j in range(0 ,length-i-1):
#             if arr[j]<arr[j+1]:
#                 arr[j],arr[j+1]=arr[j+1],arr[j]
#                 # print(arr[j],arr[j+1])

# finding(lists)
# print(lists)
n=int(input())

a=0
b=1
c=a+b
list=[]

for i in range(n):
    a=b
    b=c
    if i==0:
            a=i
    elif i==1:
            b=i
    else:
        c=a+b
        list+=[c]
print(list[n-1])
        

        


