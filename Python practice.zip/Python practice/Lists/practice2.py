string_input="Bajineni saketh"
input_chars=['a','b','c','i','n','k']
for i in input_chars:
    count=0
    for j in string_input:
        if i in j:
            count+=1
    print(i,count)



