import re
x="the future world is depends on AI world"
y=re.findall("ld",x)
print(y)