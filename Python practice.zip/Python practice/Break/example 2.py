i=0
while i<10:
    if i==2:
        break
    print(i)
    i=i+1
print("end")