for i in range(0,10):
    if i==2:
        break
    print(i)
print("end")