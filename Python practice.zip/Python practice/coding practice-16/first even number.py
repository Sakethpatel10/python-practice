n=int(input())
for i in range(1,n+1):
    inputs=int(input())
    if inputs%2==0:
        print(inputs)
        break