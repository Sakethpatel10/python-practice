word=input()
length=len(word)
vowels=["A","E","I","O","U","a","e","i","o","u"]
value=False
sum=""
for i in word:
    if i not in vowels:
        sum=sum+i
print(sum)


        
        
    
        
