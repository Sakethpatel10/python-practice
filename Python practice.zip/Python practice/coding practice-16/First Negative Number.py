n=int(input())
for i in range(n):
    b=int(input())
    if b<0:
        print(b)
        break

        