word=input()
sum=""
for i in word:
    if i.isupper():
        sum=i
print(sum)
        
    