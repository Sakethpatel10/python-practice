word1=input()
word2=input()
removing_spaces=word1.split()
remove_2=word2.split()
length1=len(removing_spaces)
length2=len(remove_2)
min_value=int(min(length1,length2))
sum=''
for i in range(min_value):
    sum+=removing_spaces[i]+remove_2[i]
if length1>length2:
    for num in range(min_value,length1):
        sum+=removing_spaces[num]
elif length2>length1:
    for num1 in range(min_value,length2):
        sum+=remove_2[num1]
print(sum)



        




