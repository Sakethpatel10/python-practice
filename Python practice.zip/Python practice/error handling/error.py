a=4
def divide(a,b):
    return a/b 
divide(4,"dsfd")

