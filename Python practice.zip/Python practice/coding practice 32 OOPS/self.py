class Start:
    def __init__(self):
        pass
    def display_items(self):
        print(self)
car=Start()
car.display_items()
print(car)
