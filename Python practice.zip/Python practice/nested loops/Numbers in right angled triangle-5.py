s=int(input())
n=int(input())
sum=0
for i in range(1,n+1):
    sum=sum+i
value=sum+s-1
print(value)