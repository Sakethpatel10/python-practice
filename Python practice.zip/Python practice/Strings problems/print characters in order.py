word=input()
length=len(word)
for i in range(1,length+1):
    index=int(input())
print(index)

    