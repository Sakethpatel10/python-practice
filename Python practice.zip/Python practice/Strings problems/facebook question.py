n=input()
length=len(n)
sum=""
for i in range(1,length+1):
    x=int(input())
    sum=sum+n[x]
print(sum)
