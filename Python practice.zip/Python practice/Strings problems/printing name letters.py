s=input()
length=len(s)
for i in range(1,length+1):
    print(s[:i])