word=input()
splitting=word.split()
joining=".".join(splitting)
print(joining)
