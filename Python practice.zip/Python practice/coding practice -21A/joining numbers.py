nums=input()
splitting=nums.split()
joining=",".join(splitting)
print(joining)