word=input()
splitting=word.split()
print(splitting)