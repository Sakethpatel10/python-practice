word=input()
splitting=word.split()
length=len(splitting)
for i in range(length):
    print(splitting[i])