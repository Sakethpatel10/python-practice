numbers=input()
splitting=numbers.split()
print(splitting)