name="sakETh"
print(name.upper())

