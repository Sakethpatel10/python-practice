sentence="teh dog and teh cat"
replacing=sentence.replace("teh","the")
print(replacing)
