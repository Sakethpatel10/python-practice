pin="4578"
is_digit=pin.isdigit()
is_4_digit=(len(pin)==4)
is_valid=is_digit and is_4_digit
print(is_valid)

