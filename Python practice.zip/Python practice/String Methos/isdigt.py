pin="1234"
print(pin.isdigit())

pin="123d"
print(pin.isdigit())