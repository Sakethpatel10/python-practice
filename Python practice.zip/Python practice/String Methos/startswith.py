url="https://google.com"
is_secure=url.startswith("https://")
print(is_secure)
if is_secure==True:
    print("the url is secured url")
else:
    print("the url is not secured url")
    