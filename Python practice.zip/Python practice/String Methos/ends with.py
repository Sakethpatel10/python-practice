gmail_id="sakethbajineni@gmail.com"
is_gmail=gmail_id.endswith("@gmail.com")
print(is_gmail)
if is_gmail==True:
    print("The given id is gmail id")
else:
    print("The given id is not gmail id")