name="SAKETH"
print(name.lower())