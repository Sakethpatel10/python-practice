mobile=" 9515901050 "
stripping=mobile.strip()
print(stripping)
print(mobile)

# strip() means it will remove spaces

name=".........M.Ravi....."
name=name.strip(".")
print(name)


name="..,,.,,Ravi,...,,,,,"
strips=name.strip(".,")
print(strips)
