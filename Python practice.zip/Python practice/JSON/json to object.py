import json
x='{"name":"saketh","age":21,"locaation":"Hyderabad"}'
y=json.loads(x)
print(y)